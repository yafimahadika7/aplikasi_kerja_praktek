<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Data Barang Transaksi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-4">
    <h4 class="mb-4">📦 Data Barang Transaksi</h4>

    <table class="table table-bordered bg-white">
        <thead class="table-dark text-center">
            <tr>
                <th>Tanggal</th>
                <th>Nama Pembeli</th>
                <th>Produk</th>
                <th>Ukuran</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Serial Number</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($item->created_at->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($item->transaksi->nama); ?></td>
                    <td><?php echo e($item->nama); ?></td>
                    <td><?php echo e($item->ukuran); ?></td>
                    <td><?php echo e($item->jumlah); ?></td>
                    <td>Rp<?php echo e(number_format($item->harga, 0, ',', '.')); ?></td>
                    <td><?php echo e($item->serial_number ?? '-'); ?></td>
                    <td><?php echo e(ucfirst($item->status)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center">Tidak ada data barang transaksi.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html><?php /**PATH D:\aplikasi_kerja_praktek\pre_order_baju\resources\views/admin/transaksi_items/index.blade.php ENDPATH**/ ?>