<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Finance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { min-height: 100vh; margin: 0; padding: 0; overflow-x: hidden; }
        .sidebar { height: 100vh; width: 220px; position: fixed; left: 0; top: 0; background-color: #343a40; color: white; padding-top: 1rem; }
        .sidebar a, .sidebar form button { color: white; padding: 10px 20px; display: block; text-decoration: none; background: none; border: none; text-align: left; }
        .sidebar a:hover, .sidebar form button:hover { background-color: #495057; }
        .topbar { height: 60px; background-color: #f8f9fa; padding: 0 1rem; display: flex; align-items: center; justify-content: space-between; margin-left: 220px; }
        .content { margin-left: 220px; padding: 2rem; }
        .card { border-radius: 12px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="text-center mb-3">
            <strong><?php echo e(Auth::user()->name); ?></strong><br>
            <small class="text-warning"><?php echo e(ucfirst(Auth::user()->role)); ?></small>
        </div>
        <a href="<?php echo e(route('finance.dashboard')); ?>">📊 Dashboard</a>
        <a href="<?php echo e(route('admin.penjualan.index')); ?>">📈 Penjualan</a>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit">🚪 Logout</button>
        </form>
    </div>

    <!-- Topbar -->
    <div class="topbar">
        <span>Dashboard Finance</span>
    </div>

    <!-- Content -->
    <div class="content">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card p-3 bg-light">
                    <h6>Total Penjualan</h6>
                    <h4 class="text-success">Rp<?php echo e(number_format($totalPenjualan, 0, ',', '.')); ?></h4>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 bg-light">
                    <h6>Jumlah Transaksi</h6>
                    <h4><?php echo e($jumlahTransaksi); ?></h4>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 bg-light">
                    <h6>Penjualan Hari Ini</h6>
                    <h4 class="text-primary">Rp<?php echo e(number_format($penjualanHariIni, 0, ',', '.')); ?></h4>
                </div>
            </div>
        </div>

        <div class="card mt-4 p-3">
            <h5>Statistik Status Transaksi</h5>
            <canvas id="chartStatus" height="200"></canvas>
        </div>
    </div>

    <script>
        const chartStatus = document.getElementById('chartStatus');
        new Chart(chartStatus, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode(array_keys($statusCounts)); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_values($statusCounts)); ?>,
                    backgroundColor: ['#28a745', '#ffc107', '#17a2b8', '#dc3545']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%'
            }
        });
    </script>
</body>
</html><?php /**PATH D:\aplikasi_kerja_praktek\pre_order_baju\resources\views/admin/dashboard/finance.blade.php ENDPATH**/ ?>