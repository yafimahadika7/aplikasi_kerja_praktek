<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>VA Info</title>
</head>
<body>
    <h3>Halo <?php echo e($transaksi->nama); ?></h3>
    <p>Terima kasih telah melakukan pemesanan di Bellybee.</p>
    <p>Berikut rincian pembayaran Anda:</p>

    <ul>
        <li>Bank: <?php echo e($transaksi->metode_pembayaran); ?></li>
        <li>Virtual Account: <strong><?php echo e($transaksi->va_number); ?></strong></li>
        <li>Total: <strong>Rp<?php echo e(number_format($transaksi->total, 0, ',', '.')); ?></strong></li>
        <li>Berlaku sampai: <?php echo e(\Carbon\Carbon::parse($transaksi->expired_at)->format('d-m-Y H:i')); ?></li>
    </ul>

    <p>Segera lakukan pembayaran sebelum VA expired.</p>
</body>
</html><?php /**PATH D:\aplikasi_kerja_praktek\pre_order_baju\resources\views/emails/virtual_account.blade.php ENDPATH**/ ?>