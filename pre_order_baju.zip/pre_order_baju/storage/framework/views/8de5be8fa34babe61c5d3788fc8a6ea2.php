<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            min-height: 100vh;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        .sidebar {
            height: 100vh;
            width: 220px;
            position: fixed;
            left: 0;
            top: 0;
            background-color: #343a40;
            color: white;
            padding-top: 1rem;
            transition: all 0.3s ease;
            z-index: 1000;
        }
        .sidebar.hide {
            left: -220px;
        }
        .sidebar a, .sidebar form button {
            color: white;
            padding: 10px 20px;
            display: block;
            text-decoration: none;
            background: none;
            border: none;
            text-align: left;
            width: 100%;
        }
        .sidebar a:hover, .sidebar form button:hover {
            background-color: #495057;
        }
        .topbar {
            height: 60px;
            background-color: #f8f9fa;
            padding: 0 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-left: 220px;
            transition: margin-left 0.3s ease;
        }
        .topbar.collapsed {
            margin-left: 0;
        }
        .content {
            margin-left: 220px;
            padding: 2rem;
            transition: margin-left 0.3s ease;
        }
        .content.collapsed {
            margin-left: 0;
        }
        .toggle-btn {
            font-size: 24px;
            background: none;
            border: none;
            cursor: pointer;
        }
        @media (max-width: 768px) {
            .sidebar {
                left: -220px;
            }
            .sidebar.show {
                left: 0;
            }
            .topbar, .content {
                margin-left: 0 !important;
            }
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="text-center mb-3">
            <strong><?php echo e(Auth::user()->name); ?></strong><br>
            <small class="<?php echo e(Auth::user()->role === 'admin' ? 'text-warning' : 'text-white'); ?>">
                <?php echo e(ucfirst(Auth::user()->role)); ?>

            </small>
        </div>

        <?php if(in_array(Auth::user()->role, ['admin', 'operation', 'finance', 'produk'])): ?>
            <a href="<?php echo e(route('admin.dashboard')); ?>">📊 Dashboard</a>
        <?php endif; ?>

        <?php if(in_array(Auth::user()->role, ['admin', 'operation'])): ?>
            <a href="<?php echo e(route('admin.transaksi.index')); ?>">💳 Transaksi</a>
        <?php endif; ?>

        <?php if(in_array(Auth::user()->role, ['admin', 'produk'])): ?>
            <a href="<?php echo e(route('admin.produk.index')); ?>">🛍️ Produk</a>
        <?php endif; ?>

        <?php if(Auth::user()->role === 'admin'): ?>
            <a href="<?php echo e(route('admin.users.index')); ?>">👤 User</a>
        <?php endif; ?>

        <?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'finance'): ?>
            <a href="<?php echo e(route('admin.penjualan.index')); ?>">📈 Penjualan</a>
        <?php endif; ?>

        <?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'operation'): ?>
            <a href="<?php echo e(route('admin.tiketing.index')); ?>">💬 Tiketing</a>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit">🚪 Logout</button>
        </form>
    </div>

    <!-- Topbar -->
    <div class="topbar" id="topbar">
        <button class="toggle-btn" onclick="toggleSidebar()">☰</button>
        <span>Manajemen Produk</span>
    </div>

    <!-- Content -->
    <div class="content" id="main-content">
        <h4>Daftar Produk</h4>

        <div class="d-flex justify-content-between mb-3">
            <a href="<?php echo e(route('admin.produk.create')); ?>" class="btn btn-primary">+ Tambah Produk</a>

            <form action="<?php echo e(route('admin.produk.index')); ?>" method="GET" class="d-flex">
                <input type="text" name="search" class="form-control me-2" placeholder="Cari nama produk..." value="<?php echo e(request('search')); ?>">
                <select name="filter" class="form-select me-2">
                    <option value="">-- Semua Kategori --</option>
                    <option value="Shirt" <?php echo e(request('filter') == 'Shirt' ? 'selected' : ''); ?>>Shirt</option>
                    <option value="Blouse" <?php echo e(request('filter') == 'Blouse' ? 'selected' : ''); ?>>Blouse</option>
                    <option value="Tunic" <?php echo e(request('filter') == 'Tunic' ? 'selected' : ''); ?>>Tunic</option>
                    <option value="Outerwear" <?php echo e(request('filter') == 'Outerwear' ? 'selected' : ''); ?>>Outerwear</option>
                    <option value="Dress" <?php echo e(request('filter') == 'Dress' ? 'selected' : ''); ?>>Dress</option>
                    <option value="Skirt" <?php echo e(request('filter') == 'Skirt' ? 'selected' : ''); ?>>Skirt</option>
                    <option value="Pants" <?php echo e(request('filter') == 'Pants' ? 'selected' : ''); ?>>Pants</option>
                    <option value="One Set" <?php echo e(request('filter') == 'One Set' ? 'selected' : ''); ?>>One Set</option>
                    <option value="Prayer Set" <?php echo e(request('filter') == 'Prayer Set' ? 'selected' : ''); ?>>Prayer Set</option>
                    <option value="Muslim Shirt" <?php echo e(request('filter') == 'Muslim Shirt' ? 'selected' : ''); ?>>Muslim Shirt</option>
                </select>
                <button class="btn btn-outline-secondary" type="submit">Cari</button>
            </form>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-striped bg-white">
                <thead class="table-dark text-center">
                    <tr>
                        <th>Gambar</th>
                        <th>Nama Produk</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th width="200">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-center">
                            <td>
                                <?php if($item->gambar): ?>
                                    <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>" width="80">
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item->nama); ?></td>
                            <td><?php echo e($item->kategori); ?></td>
                            <td>Rp<?php echo e(number_format($item->harga, 0, ',', '.')); ?></td>
                            <td>
                                <?php
                                    $stok = json_decode($item->stock, true);
                                ?>

                                <?php if(is_array($stok)): ?>
                                    <?php $__currentLoopData = $stok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukuran => $jumlah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div><?php echo e($ukuran); ?>: <?php echo e($jumlah); ?></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <a href="<?php echo e(route('admin.produk.edit', $item->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                <form action="<?php echo e(route('admin.produk.destroy', $item->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus produk ini?')">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">Belum ada produk</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- JavaScript -->
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const content = document.getElementById('main-content');
            const topbar = document.getElementById('topbar');

            sidebar.classList.toggle('hide');
            content.classList.toggle('collapsed');
            topbar.classList.toggle('collapsed');
        }
    </script>

</body>
</html><?php /**PATH D:\aplikasi_kerja_praktek\pre_order_baju\resources\views/admin/produk/index.blade.php ENDPATH**/ ?>