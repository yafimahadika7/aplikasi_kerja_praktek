<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Detail Tiket Komplain</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .chat-container {
            padding: 1rem;
            background: #f8f9fa;
            min-height: 300px;
            max-height: 500px;
            overflow-y: auto;
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .bubble-row {
            display: flex;
            width: 100%;
        }
        .bubble {
            max-width: 65%;
            padding: 10px 16px;
            border-radius: 18px;
            font-size: 15px;
            line-height: 1.4;
            word-break: break-word;
            margin-bottom: 2px;
        }
        .bubble-user {
            background: #e4e6eb;
            color: #222;
            text-align: left;
            border-bottom-left-radius: 4px;
            border-top-left-radius: 4px;
            border-top-right-radius: 16px;
            border-bottom-right-radius: 16px;
            margin-right: auto;
        }
        .bubble-admin {
            background: #007bff;
            color: #fff;
            text-align: right;
            border-bottom-right-radius: 4px;
            border-top-right-radius: 4px;
            border-top-left-radius: 16px;
            border-bottom-left-radius: 16px;
            margin-left: auto;
        }
        .chat-meta {
            font-size: 11px;
            color: #888;
            margin-top: 2px;
        }
        .bubble-username {
            font-weight: bold;
            font-size: 13px;
            margin-bottom: 2px;
            display: block;
        }
        @media (max-width: 600px) {
            .chat-container { padding: 0.5rem; }
            .bubble { max-width: 85%; font-size: 14px;}
        }
    </style>
</head>
<body>
<div class="container my-4">
    <a href="<?php echo e(route('admin.tiketing.index')); ?>" class="btn btn-secondary mb-3">← Kembali</a>
    <div class="card mb-3">
        <div class="card-body">
            <h5 class="card-title">Detail Tiket #<?php echo e($komplain->id); ?></h5>
            <p><b>Nama:</b> <?php echo e($komplain->nama); ?></p>
            <p><b>Kontak:</b> <?php echo e($komplain->kontak); ?></p>
            <p><b>Topik:</b> <?php echo e($komplain->topik); ?></p>
            <p><b>Status:</b>
                <span class="badge bg-<?php echo e($komplain->status == 'closed' ? 'secondary' : 'success'); ?>">
                    <?php echo e(ucfirst($komplain->status)); ?>

                </span>
            </p>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-header"><b>Riwayat Chat</b></div>
        <div class="card-body">
            <div class="chat-container mb-4" id="chatBox">
                <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($msg->pengirim == 'admin'): ?>
                        <div class="bubble-row justify-content-end">
                            <div class="bubble bubble-admin">
                                <span class="bubble-username">Admin</span>
                                <?php echo e($msg->pesan); ?>

                                <div class="chat-meta"><?php echo e($msg->created_at->format('d/m/Y H:i')); ?></div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="bubble-row justify-content-start">
                            <div class="bubble bubble-user">
                                <span class="bubble-username"><?php echo e($komplain->nama ?? 'Pelanggan'); ?></span>
                                <?php echo e($msg->pesan); ?>

                                <div class="chat-meta"><?php echo e($msg->created_at->format('d/m/Y H:i')); ?></div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted text-center">Belum ada pesan.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if($komplain->status != 'closed'): ?>
    <form action="<?php echo e(route('admin.tiketing.reply', $komplain->id)); ?>" method="POST" class="d-flex gap-2">
        <?php echo csrf_field(); ?>
        <input type="text" name="pesan" class="form-control" placeholder="Tulis balasan..." required>
        <button type="submit" class="btn btn-primary">Balas</button>
    </form>
    <form action="<?php echo e(route('admin.tiketing.close', $komplain->id)); ?>" method="POST" class="mt-2">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-danger" onclick="return confirm('Tutup tiket ini?')">Tutup Tiket</button>
    </form>
    <?php else: ?>
    <div class="alert alert-secondary text-center">Tiket sudah ditutup</div>
    <?php endif; ?>
</div>
</body>
</html><?php /**PATH D:\aplikasi_kerja_praktek\pre_order_baju\resources\views/admin/tiketing/show.blade.php ENDPATH**/ ?>